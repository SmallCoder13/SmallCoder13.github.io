# Copyright (c) 2009, Giampaolo Rodola'. All rights reserved.
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.

"""FreeBSD, OpenBSD and NetBSD platforms implementation."""

import errno
import functools
from collections import defaultdict
from collections import namedtuple

from . import _ntuples as ntp
from . import _psposix
from . import _psutil
from ._common import FREEBSD
from ._common import NETBSD
from ._common import OPENBSD
from ._common import AccessDenied
from ._common import NoSuchProcess
from ._common import ZombieProcess
from ._common import conn_tmap
from ._common import conn_to_ntuple
from ._common import debug
from ._common import memoize_when_activated
from ._common import warn
from ._enums import BatteryTime
from ._enums import ConnectionStatus
from ._enums import NicDuplex
from ._enums import ProcessStatus

__extra__all__ = []


# =====================================================================
# --- globals
# =====================================================================


if FREEBSD:
    PROC_STATUSES = {
        _psutil.SIDL: ProcessStatus.STATUS_IDLE,
        _psutil.SRUN: ProcessStatus.STATUS_RUNNING,
        _psutil.SSLEEP: ProcessStatus.STATUS_SLEEPING,
        _psutil.SSTOP: ProcessStatus.STATUS_STOPPED,
        _psutil.SZOMB: ProcessStatus.STATUS_ZOMBIE,
        _psutil.SWAIT: ProcessStatus.STATUS_WAITING,
        _psutil.SLOCK: ProcessStatus.STATUS_LOCKED,
    }
elif OPENBSD:
    PROC_STATUSES = {
        _psutil.SIDL: ProcessStatus.STATUS_IDLE,
        _psutil.SSLEEP: ProcessStatus.STATUS_SLEEPING,
        _psutil.SSTOP: ProcessStatus.STATUS_STOPPED,
        # According to /usr/include/sys/proc.h SZOMB is unused.
        # test_zombie_process() shows that SDEAD is the right
        # equivalent. Also it appears there's no equivalent of
        # psutil.STATUS_DEAD. SDEAD really means STATUS_ZOMBIE.
        # _psutil.SZOMB: ProcStatus.STATUS_ZOMBIE,
        _psutil.SDEAD: ProcessStatus.STATUS_ZOMBIE,
        _psutil.SZOMB: ProcessStatus.STATUS_ZOMBIE,
        # From http://www.eecs.harvard.edu/~margo/cs161/videos/proc.h.txt
        # OpenBSD has SRUN and SONPROC: SRUN indicates that a process
        # is runnable but *not* yet running, i.e. is on a run queue.
        # SONPROC indicates that the process is actually executing on
        # a CPU, i.e. it is no longer on a run queue.
        # As such we'll map SRUN to STATUS_WAKING and SONPROC to
        # STATUS_RUNNING
        _psutil.SRUN: ProcessStatus.STATUS_WAKING,
        _psutil.SONPROC: ProcessStatus.STATUS_RUNNING,
    }
elif NETBSD:
    PROC_STATUSES = {
        _psutil.SIDL: ProcessStatus.STATUS_IDLE,
        _psutil.SSLEEP: ProcessStatus.STATUS_SLEEPING,
        _psutil.SSTOP: ProcessStatus.STATUS_STOPPED,
        _psutil.SZOMB: ProcessStatus.STATUS_ZOMBIE,
        _psutil.SRUN: ProcessStatus.STATUS_WAKING,
        _psutil.SONPROC: ProcessStatus.STATUS_RUNNING,
        _psutil.SSUSPENDED: ProcessStatus.STATUS_SUSPENDED,
    }

TCP_STATUSES = {
    _psutil.TCPS_ESTABLISHED: ConnectionStatus.CONN_ESTABLISHED,
    _psutil.TCPS_SYN_SENT: ConnectionStatus.CONN_SYN_SENT,
    _psutil.TCPS_SYN_RECEIVED: ConnectionStatus.CONN_SYN_RECV,
    _psutil.TCPS_FIN_WAIT_1: ConnectionStatus.CONN_FIN_WAIT1,
    _psutil.TCPS_FIN_WAIT_2: ConnectionStatus.CONN_FIN_WAIT2,
    _psutil.TCPS_TIME_WAIT: ConnectionStatus.CONN_TIME_WAIT,
    _psutil.TCPS_CLOSED: ConnectionStatus.CONN_CLOSE,
    _psutil.TCPS_CLOSE_WAIT: ConnectionStatus.CONN_CLOSE_WAIT,
    _psutil.TCPS_LAST_ACK: ConnectionStatus.CONN_LAST_ACK,
    _psutil.TCPS_LISTEN: ConnectionStatus.CONN_LISTEN,
    _psutil.TCPS_CLOSING: ConnectionStatus.CONN_CLOSING,
    _psutil.PSUTIL_CONN_NONE: ConnectionStatus.CONN_NONE,
}

PAGESIZE = _psutil.getpagesize()
AF_LINK = _psutil.AF_LINK

HAS_PROC_NUM_THREADS = hasattr(_psutil, "proc_num_threads")


# =====================================================================
# --- memory
# =====================================================================


def virtual_memory():
    d = _psutil.virtual_mem()
    return ntp.svmem(**d)


def swap_memory():
    """System swap memory as a (total, used, free, percent, sin, sout)
    named tuple. sin and sout are always 0 on OpenBSD
    """
    d = _psutil.swap_mem()
    return ntp.sswap(**d)


# malloc / heap functions (FreeBSD / NetBSD)
if hasattr(_psutil, "heap_info"):
    heap_info = _psutil.heap_info
    heap_trim = _psutil.heap_trim


# =====================================================================
# --- CPU
# =====================================================================


def cpu_times():
    """Return system per-CPU times as a named tuple."""
    user, nice, system, idle, irq = _psutil.cpu_times()
    return ntp.scputimes(user, system, idle, nice, irq)


def per_cpu_times():
    """Return system CPU times as a named tuple."""
    ret = []
    for cpu_t in _psutil.per_cpu_times():
        user, nice, system, idle, irq = cpu_t
        item = ntp.scputimes(user, system, idle, nice, irq)
        ret.append(item)
    return ret


def cpu_count_logical():
    """Return the number of logical CPUs in the system."""
    return _psutil.cpu_count_logical()


if OPENBSD or NETBSD:

    def cpu_count_cores():
        # OpenBSD and NetBSD do not implement this.
        return 1 if cpu_count_logical() == 1 else None

else:

    def cpu_count_cores():
        """Return the number of CPU cores in the system."""
        return _psutil.cpu_count_cores()


def cpu_stats():
    """Return various CPU stats as a named tuple."""
    if FREEBSD:
        # Note: the C ext is returning some metrics we are not exposing:
        # traps.
        ctxsw, intrs, soft_intrs, syscalls, _traps = _psutil.cpu_stats()
    elif NETBSD or OPENBSD:
        # Note: the C ext is returning some metrics we are not exposing:
        # traps, faults and forks.
        ctxsw, intrs, soft_intrs, syscalls, _traps, _faults, _forks = (
            _psutil.cpu_stats()
        )
    return ntp.scpustats(ctxsw, intrs, soft_intrs, syscalls)


if FREEBSD:

    def cpu_freq():
        """Return frequency metrics for CPUs. As of Dec 2018 only
        CPU 0 appears to be supported by FreeBSD and all other cores
        match the frequency of CPU 0.
        """
        ret = []
        num_cpus = cpu_count_logical()
        for cpu in range(num_cpus):
            try:
                current, available_freq = _psutil.cpu_freq(cpu)
            except NotImplementedError:
                continue
            min_freq = max_freq = None
            if available_freq:
                try:
                    min_freq = int(available_freq.split(" ")[-1].split("/")[0])
                except (IndexError, ValueError):
                    min_freq = None
                try:
                    max_freq = int(available_freq.split(" ")[0].split("/")[0])
                except (IndexError, ValueError):
                    max_freq = None
            ret.append(ntp.scpufreq(current, min_freq, max_freq))
        return ret

elif OPENBSD:

    def cpu_freq():
        curr = float(_psutil.cpu_freq())
        return [ntp.scpufreq(curr, 0.0, 0.0)]


# =====================================================================
# --- disks
# =====================================================================


def disk_partitions(all=False):
    """Return mounted disk partitions as a list of named tuples.
    'all' argument is ignored, see:
    https://github.com/giampaolo/psutil/issues/906.
    """
    retlist = []
    partitions = _psutil.disk_partitions()
    for partition in partitions:
        device, mountpoint, fstype, opts = partition
        ntuple = ntp.sdiskpart(device, mountpoint, fstype, opts)
        retlist.append(ntuple)
    return retlist


disk_usage = _psposix.disk_usage
disk_io_counters = _psutil.disk_io_counters


# =====================================================================
# --- network
# =====================================================================


net_io_counters = _psutil.net_io_counters
net_if_addrs = _psutil.net_if_addrs


def net_if_stats():
    """Get NIC stats (isup, duplex, speed, mtu)."""
    names = net_io_counters().keys()
    ret = {}
    for name in names:
        try:
            mtu = _psutil.net_if_mtu(name)
            flags = _psutil.net_if_flags(name)
            duplex, speed = _psutil.net_if_duplex_speed(name)
        except OSError as err:
            # https://github.com/giampaolo/psutil/issues/1279
            if err.errno != errno.ENODEV:
                raise
        else:
            duplex = NicDuplex(duplex)
            output_flags = ','.join(flags)
            isup = 'running' in flags
            ret[name] = ntp.snicstats(isup, duplex, speed, mtu, output_flags)
    return ret


def net_connections(kind):
    """System-wide network connections."""
    families, types = conn_tmap[kind]
    ret = set()
    if OPENBSD:
        rawlist = _psutil.net_connections(-1, families, types)
    elif NETBSD:
        rawlist = _psutil.net_connections(-1, kind)
    else:  # FreeBSD
        rawlist = _psutil.net_connections(families, types)

    for item in rawlist:
        fd, fam, type, laddr, raddr, status, pid = item
        nt = conn_to_ntuple(
            fd, fam, type, laddr, raddr, status, TCP_STATUSES, pid
        )
        ret.add(nt)
    return list(ret)


# =====================================================================
#  --- sensors
# =====================================================================


if FREEBSD:

    def sensors_battery():
        """Return battery info."""
        try:
            percent, minsleft, power_plugged = _psutil.sensors_battery()
        except NotImplementedError:
            # See: https://github.com/giampaolo/psutil/issues/1074
            return None
        power_plugged = power_plugged == 1
        if power_plugged:
            secsleft = BatteryTime.POWER_TIME_UNLIMITED
        elif minsleft == -1:
            secsleft = BatteryTime.POWER_TIME_UNKNOWN
        else:
            secsleft = minsleft * 60
        return ntp.sbattery(percent, secsleft, power_plugged)

    def sensors_temperatures():
        """Return CPU cores temperatures if available, else an empty dict."""
        ret = defaultdict(list)
        num_cpus = cpu_count_logical()
        for cpu in range(num_cpus):
            try:
                current, high = _psutil.sensors_cpu_temperature(cpu)
                if high <= 0:
                    high = None
                name = f"Core {cpu}"
                ret["coretemp"].append(ntp.shwtemp(name, current, high, high))
            except NotImplementedError:
                pass

        return ret


# =====================================================================
#  --- other system functions
# =====================================================================


def boot_time():
    """The system boot time expressed in seconds since the epoch."""
    return _psutil.boot_time()


if NETBSD:

    try:
        INIT_BOOT_TIME = boot_time()
    except Exception as err:  # noqa: BLE001
        # Don't want to crash at import time.
        warn(f"boot_time() failed on import: {err!r}")
        INIT_BOOT_TIME = 0

    def adjust_proc_create_time(ctime):
        """Account for system clock updates."""
        if INIT_BOOT_TIME == 0:
            return ctime

        diff = INIT_BOOT_TIME - boot_time()
        if diff == 0 or abs(diff) < 1:
            return ctime

        debug("system clock was updated; adjusting process create_time()")
        if diff < 0:
            return ctime - diff
        return ctime + diff


def users():
    """Return currently connected users as a list of named tuples."""
    retlist = []
    rawlist = _psutil.users()
    for item in rawlist:
        user, tty, hostname, tstamp, pid = item
        if tty == '~':
            continue  # reboot or shutdown
        nt = ntp.suser(user, tty or None, hostname, tstamp, pid)
        retlist.append(nt)
    return retlist


# =====================================================================
# --- processes
# =====================================================================


@functools.lru_cache
def _pid_0_exists():
    try:
        Process(0).name()
    except NoSuchProcess:
        return False
    except AccessDenied:
        return True
    else:
        return True


def pids():
    """Returns a list of PIDs currently running on the system."""
    ret = _psutil.pids()
    if OPENBSD and (0 not in ret) and _pid_0_exists():
        # On OpenBSD the kernel does not return PID 0 (neither does
        # ps) but it's actually querable (Process(0) will succeed).
        ret.insert(0, 0)
    return ret


if NETBSD:

    def pid_exists(pid):
        exists = _psposix.pid_exists(pid)
        if not exists:
            # We do this because _psposix.pid_exists() lies in case of
            # zombie processes.
            return pid in pids()
        else:
            return True

elif OPENBSD:

    def pid_exists(pid):
        exists = _psposix.pid_exists(pid)
        if not exists:
            return False
        else:
            # OpenBSD seems to be the only BSD platform where
            # _psposix.pid_exists() returns True for thread IDs (tids),
            # so we can't use it.
            return pid in pids()

else:  # FreeBSD
    pid_exists = _psposix.pid_exists


def wrap_exceptions(fun):
    """Decorator which translates bare OSError exceptions into
    NoSuchProcess and AccessDenied.
    """

    @functools.wraps(fun)
    def wrapper(self, *args, **kwargs):
        pid, ppid, name = self.pid, self._ppid, self._name
        try:
            return fun(self, *args, **kwargs)
        except ProcessLookupError as err:
            if _psutil.proc_is_zombie(pid):
                raise ZombieProcess(pid, name, ppid) from err
            raise NoSuchProcess(pid, name) from err
        except PermissionError as err:
            raise AccessDenied(pid, name) from err
        except _psutil.ZombieProcessError as err:
            raise ZombieProcess(pid, name, ppid) from err
        except OSError as err:
            if pid == 0 and 0 in pids():
                raise AccessDenied(pid, name) from err
            raise err from None

    return wrapper


class Process:
    """Wrapper class around underlying C implementation."""

    __slots__ = ["_cache", "_name", "_ppid", "pid"]

    def __init__(self, pid):
        self.pid = pid
        self._name = None
        self._ppid = None

    def _assert_alive(self):
        """Raise NSP if the process disappeared on us."""
        # For those C function who do not raise NSP, possibly returning
        # incorrect or incomplete result.
        _psutil.proc_name(self.pid)

    @wrap_exceptions
    @memoize_when_activated
    def oneshot(self):
        """Retrieves multiple process info in one shot as a raw dict."""
        return _psutil.proc_oneshot_kinfo(self.pid)

    def oneshot_enter(self):
        self.oneshot.cache_activate(self)

    def oneshot_exit(self):
        self.oneshot.cache_deactivate(self)

    @wrap_exceptions
    def name(self):
        name = self.oneshot()["name"]
        return name if name is not None else _psutil.proc_name(self.pid)

    @wrap_exceptions
    def exe(self):
        if FREEBSD or NETBSD:
            if self.pid == 0:
                return ''  # else NSP
            return _psutil.proc_exe(self.pid)
        else:
            # OpenBSD: exe cannot be determined; references:
            # https://chromium.googlesource.com/chromium/src/base/+/master/base_paths_posix.cc
            # We try our best guess by using which against the first
            # cmdline arg (may return None).
            import shutil

            cmdline = self.cmdline()
            if cmdline:
                return shutil.which(cmdline[0]) or ""
            else:
                return ""

    @wrap_exceptions
    def cmdline(self):
        if OPENBSD and self.pid == 0:
            return []  # ...else it crashes
        elif NETBSD or OPENBSD:
            # XXX - most of the times the underlying sysctl() call on
            # NetBSD and OpenBSD returns a truncated string. Also
            # /proc/pid/cmdline behaves the same so it looks like this
            # is a kernel bug.
            try:
                return _psutil.proc_cmdline(self.pid)
            except OSError as err:
                if err.errno in {errno.EINVAL, errno.EFAULT}:
                    debug(f"cmdline(): ignoring {err!r}")
                    pid, name, ppid = self.pid, self._name, self._ppid
                    if _psutil.proc_is_zombie(self.pid):
                        raise ZombieProcess(pid, name, ppid) from err
                    if not pid_exists(self.pid):
                        raise NoSuchProcess(pid, name) from err
                    return []
                else:
                    raise
        else:
            return _psutil.proc_cmdline(self.pid)

    @wrap_exceptions
    def environ(self):
        return _psutil.proc_environ(self.pid)

    @wrap_exceptions
    def terminal(self):
        tty_nr = self.oneshot()["ttynr"]
        if tty_nr == _psutil.NODEV:
            return None
        return _psposix.get_terminal(tty_nr)

    @wrap_exceptions
    def ppid(self):
        self._ppid = self.oneshot()["ppid"]
        return self._ppid

    @wrap_exceptions
    def uids(self):
        d = self.oneshot()
        return ntp.puids(d["real_uid"], d["effective_uid"], d["saved_uid"])

    @wrap_exceptions
    def gids(self):
        d = self.oneshot()
        return ntp.pgids(d["real_gid"], d["effective_gid"], d["saved_gid"])

    @wrap_exceptions
    def cpu_times(self):
        d = self.oneshot()
        return ntp.pcputimes(
            d["user_time"], d["sys_time"], d["ch_user_time"], d["ch_sys_time"]
        )

    if FREEBSD:

        @wrap_exceptions
        def cpu_num(self):
            return self.oneshot()["cpunum"]

    @wrap_exceptions
    def memory_info(self):
        d = self.oneshot()
        return ntp.pmem(
            rss=d["rss"],
            vms=d["vms"],
            text=d["memtext"],
            data=d["memdata"],
            stack=d["memstack"],
            peak_rss=d["peak_rss"],
        )

    @wrap_exceptions
    def create_time(self, monotonic=False):
        ctime = self.oneshot()["create_time"]
        if NETBSD and not monotonic:
            # NetBSD: ctime subject to system clock updates.
            ctime = adjust_proc_create_time(ctime)
        return ctime

    @wrap_exceptions
    def num_threads(self):
        if HAS_PROC_NUM_THREADS:
            # FreeBSD / NetBSD
            return _psutil.proc_num_threads(self.pid)
        else:
            return len(self.threads())

    @wrap_exceptions
    def num_ctx_switches(self):
        d = self.oneshot()
        return ntp.pctxsw(d["ctx_switches_vol"], d["ctx_switches_unvol"])

    @wrap_exceptions
    def page_faults(self):
        d = self.oneshot()
        return ntp.ppagefaults(d["min_faults"], d["maj_faults"])

    @wrap_exceptions
    def threads(self):
        # Note: on OpenSBD this (/dev/mem) requires root access.
        rawlist = _psutil.proc_threads(self.pid)
        retlist = []
        for thread_id, utime, stime in rawlist:
            ntuple = ntp.pthread(thread_id, utime, stime)
            retlist.append(ntuple)
        if OPENBSD:
            self._assert_alive()
        return retlist

    @wrap_exceptions
    def net_connections(self, kind='inet'):
        families, types = conn_tmap[kind]
        ret = []

        if NETBSD:
            rawlist = _psutil.net_connections(self.pid, kind)
        elif OPENBSD:
            rawlist = _psutil.net_connections(self.pid, families, types)
        else:
            rawlist = _psutil.proc_net_connections(self.pid, families, types)

        for item in rawlist:
            fd, fam, type, laddr, raddr, status = item[:6]
            if FREEBSD:
                if (fam not in families) or (type not in types):
                    continue
            nt = conn_to_ntuple(
                fd, fam, type, laddr, raddr, status, TCP_STATUSES
            )
            ret.append(nt)

        self._assert_alive()
        return ret

    @wrap_exceptions
    def wait(self, timeout=None):
        return _psposix.wait_pid(self.pid, timeout)

    @wrap_exceptions
    def nice_get(self):
        # Also available via POSIX getpriority(), but can raise NSP
        # for not fully initialized processes in SIDL state, see:
        # https://github.com/giampaolo/psutil/issues/2903
        return self.oneshot()["nice"]

    @wrap_exceptions
    def nice_set(self, value):
        return _psutil.proc_priority_set(self.pid, value)

    @wrap_exceptions
    def status(self):
        code = self.oneshot()["status"]
        # XXX is '?' legit? (we're not supposed to return it anyway)
        return PROC_STATUSES.get(code, '?')

    @wrap_exceptions
    def io_counters(self):
        d = self.oneshot()
        return ntp.pio(d["read_io_count"], d["write_io_count"], -1, -1)

    @wrap_exceptions
    def cwd(self):
        """Return process current working directory."""
        # sometimes we get an empty string, in which case we turn
        # it into None
        if OPENBSD and self.pid == 0:
            return ""  # ...else it would raise EINVAL
        return _psutil.proc_cwd(self.pid)

    nt_mmap_grouped = namedtuple(
        'mmap', 'path rss, private, ref_count, shadow_count'
    )
    nt_mmap_ext = namedtuple(
        'mmap', 'addr, perms path rss, private, ref_count, shadow_count'
    )

    @wrap_exceptions
    def open_files(self):
        """Return files opened by process as a list of named tuples."""
        rawlist = _psutil.proc_open_files(self.pid)
        return [ntp.popenfile(path, fd) for path, fd in rawlist]

    @wrap_exceptions
    def num_fds(self):
        """Return the number of file descriptors opened by this process."""
        ret = _psutil.proc_num_fds(self.pid)
        if NETBSD:
            self._assert_alive()
        return ret

    # --- FreeBSD only APIs

    if FREEBSD:

        @wrap_exceptions
        def cpu_affinity_get(self):
            return _psutil.proc_cpu_affinity_get(self.pid)

        @wrap_exceptions
        def cpu_affinity_set(self, cpus):
            # preemptively check if CPUs are valid because the C
            # function has a weird behavior in case of invalid CPUs,
            # see: https://github.com/giampaolo/psutil/issues/586
            allcpus = set(range(len(per_cpu_times())))
            for cpu in cpus:
                if cpu not in allcpus:
                    msg = f"invalid CPU {cpu!r} (choose between {allcpus})"
                    raise ValueError(msg)
            try:
                _psutil.proc_cpu_affinity_set(self.pid, cpus)
            except OSError as err:
                # 'man cpuset_setaffinity' about EDEADLK:
                # <<the call would leave a thread without a valid CPU to run
                # on because the set does not overlap with the thread's
                # anonymous mask>>
                if err.errno in {errno.EINVAL, errno.EDEADLK}:
                    for cpu in cpus:
                        if cpu not in allcpus:
                            msg = (
                                f"invalid CPU {cpu!r} (choose between"
                                f" {allcpus})"
                            )
                            raise ValueError(msg) from err
                raise

        @wrap_exceptions
        def memory_maps(self):
            return _psutil.proc_memory_maps(self.pid)

        @wrap_exceptions
        def rlimit(self, resource, limits=None):
            if limits is None:
                return _psutil.proc_getrlimit(self.pid, resource)
            else:
                if len(limits) != 2:
                    msg = (
                        "second argument must be a (soft, hard) tuple, got"
                        f" {limits!r}"
                    )
                    raise ValueError(msg)
                soft, hard = limits
                return _psutil.proc_setrlimit(self.pid, resource, soft, hard)
